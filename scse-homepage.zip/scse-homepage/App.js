import  * as React from 'react';
import { Button, View, Text,TextInput, } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

class HomeScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Home Screen</Text>
        <Button
          title="JOURNAL"
          onPress={() => this.props.navigation.navigate('Journal')}
        />
        <Button
          title="GALLERY"
          onPress={() => this.props.navigation.navigate('Details')}
        />
      </View>
    );
  }
}

class JournalScreen extends React.Component {
  state = {
    text: ''
  };

  render() {
    return (
      <View style={{ flex: 1, alignItems: 'top', justifyContent: 'center' }}>
        <Text>Date:19 January 2020</Text>
        <TextInput style={{
          height:550 ,
           width: 400,
          fontSize: 20,
    borderColor: 'darkslategrey',
    borderWidth: 1,
    paddingHorizontal: '2%',
    multiline: true }}
          onChangeText={text => this.setState({ text })}
          value={this.state.text}
        />

      </View>
    );
  }
}

class GalleryScreen extends React.Component {
  render() {
    return (
      <View style={{ flex: 0.25, alignItems: 'top', justifyContent: 'center' }}>
        <Text>Journal Entries</Text>
      </View>
    );
  }
}

const RootStack = createStackNavigator(
  {
    Home: HomeScreen,
    Details: GalleryScreen,
    Journal: JournalScreen,
  },
  {
    initialRouteName: 'Home',
  }
);

const AppContainer = createAppContainer(RootStack);

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}